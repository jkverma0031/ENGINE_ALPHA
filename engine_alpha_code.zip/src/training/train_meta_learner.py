# ==============================================================================
# ENGINE_ALPHA - ENTERPRISE NEURAL META-LEARNER & CALIBRATOR
# Core Component: src/training/train_meta_learner.py
# Description: Generates Level-2 Out-of-Fold prediction matrices via Multi-GPU
# batched inference. Trains a Context-Aware Attention Aggregator to dynamically 
# shift trust between models based on anomaly scores, and applies Platt Scaling.
# ==============================================================================

import os
import sys
import yaml
import time
import json
import logging
import numpy as np
import pandas as pd
import joblib

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import LBFGS
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, roc_auc_score, brier_score_loss
import xgboost as xgb
from torch.cuda.amp import autocast

# 🚀 ULTRA-MAX PERFORMANCE TWEAK
torch.backends.cudnn.benchmark = True

# Setup module-level logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] [MetaLearner] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger(__name__)

# Resolve Root and Imports
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.append(PROJECT_ROOT)

try:
    from config import feature_config
    from src.data.dataset_loader import WingoSequenceDataset
    from src.models.lstm_brain import WingoMTLLSTM
    from src.models.transformer_brain import WingoMTLTransformer
    from src.models.autoencoder import WingoTemporalVAE
except ImportError as e:
    logger.error(f"Failed to import project modules: {e}")
    sys.exit(1)


class NeuralMetaAggregator(nn.Module):
    """
    Level-2 Context-Aware Attention Aggregator.
    Instead of static weights, this network uses Squeeze-and-Excitation (SE) 
    mechanics. It evaluates the VAE Anomaly score and model confidences to 
    dynamically assign voting power to [LSTM, Trans, XGBoost] on a per-trade basis.
    """
    def __init__(self, num_models: int = 4):
        super(NeuralMetaAggregator, self).__init__()
        self.num_models = num_models
        
        # Advanced Attention Gating Network
        self.attention_gate = nn.Sequential(
            nn.Linear(num_models, 32),
            nn.Mish(),
            nn.Dropout(0.1),
            nn.Linear(32, num_models)
        )
        
        # Temperature controls the "sharpness" of the voting consensus
        self.temperature = nn.Parameter(torch.ones(1) * 1.5)
        self.bias = nn.Parameter(torch.zeros(1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x shape: (Batch, Num_Models) -> [LSTM_Prob, Trans_Prob, XGB_Prob, VAE_Error]
        """
        # Calculate dynamic attention weights for this specific batch
        gate_logits = self.attention_gate(x)
        
        # Apply temperature scaling and Softmax to ensure weights sum to 1.0
        dynamic_weights = F.softmax(gate_logits / self.temperature, dim=1)
        
        # Weighted combination of the base models' predictions
        combined_ensemble = torch.sum(x * dynamic_weights, dim=1, keepdim=True) + self.bias
        return combined_ensemble


class Level2DataBuilder:
    """
    Loads all frozen models and generates the Level-2 Matrix (X_meta) using 
    massive 2048-row DataParallel batches to saturate the Dual T4 GPUs.
    """
    def __init__(self, config: dict, device: torch.device):
        self.config = config
        self.device = device
        
        self.sup_dir = os.path.join(PROJECT_ROOT, self.config['paths']['supervised_artifact_dir'])
        self.unsup_dir = os.path.join(PROJECT_ROOT, self.config['paths']['unsupervised_artifact_dir'])
        self.scaler_path = os.path.join(PROJECT_ROOT, self.config['paths']['scaler_artifact_dir'], "master_scaler.joblib")
        
        self.seq_len = self.config['data_pipeline']['feature_engineering']['sequence_length']
        self.gpu_count = torch.cuda.device_count()

    def load_frozen_artifacts(self, input_dim: int):
        logger.info("Initializing Frozen Artifact Vault...")
        
        # 1. Load LSTM
        self.lstm = WingoMTLLSTM(
            input_dim=input_dim,
            hidden_dim=self.config['models']['lstm']['hidden_dim'],
            num_layers=self.config['models']['lstm']['num_layers']
        ).to(self.device)
        lstm_ckpt = torch.load(os.path.join(self.sup_dir, "lstm_best_weights.pt"), map_location=self.device)
        self.lstm.load_state_dict(lstm_ckpt['model_state_dict'])
        self.lstm.eval()
        
        # 2. Load Transformer
        self.transformer = WingoMTLTransformer(
            input_dim=input_dim,
            seq_len=self.seq_len,
            d_model=self.config['models']['transformer']['d_model'],
            nhead=self.config['models']['transformer']['nhead'],
            num_layers=self.config['models']['transformer']['num_layers']
        ).to(self.device)
        trans_ckpt = torch.load(os.path.join(self.sup_dir, "transformer_best_weights.pt"), map_location=self.device)
        self.transformer.load_state_dict(trans_ckpt['model_state_dict'])
        self.transformer.eval()
        
        # 3. Load VAE
        self.vae = WingoTemporalVAE(
            input_dim=input_dim, 
            sequence_length=self.seq_len, 
            latent_dim=self.config['models']['autoencoder']['bottleneck_dim']
        ).to(self.device)
        self.vae.load_state_dict(torch.load(os.path.join(self.unsup_dir, "temporal_vae_weights.pt"), map_location=self.device))
        self.vae.eval()
        
        # 4. Load XGBoost
        self.xgb = xgb.XGBClassifier()
        self.xgb.load_model(os.path.join(self.sup_dir, "xgboost_master.json"))
        
        # 🚀 Distribute Deep Models Across Dual GPUs for Inference
        if self.gpu_count > 1 and self.device.type == 'cuda':
            logger.info(f"🔥 Distributing Frozen Models across {self.gpu_count} GPUs for Precomputation!")
            self.lstm = nn.DataParallel(self.lstm)
            self.transformer = nn.DataParallel(self.transformer)
            self.vae = nn.DataParallel(self.vae)
            
        logger.info("All Base Brains Loaded and Frozen Successfully.")

    def generate_meta_matrix(self, val_df: pd.DataFrame, scaler):
        """Passes data through frozen brains using High-Speed Batching."""
        logger.info("Generating Level-2 Meta-Matrix using Multi-GPU Batched Inference...")
        
        feature_cols = feature_config.MODEL_INPUT_FEATURES
        X_raw = val_df[feature_cols].values
        Y_true = val_df[feature_config.TARGETS['binary_size']].values
        
        X_scaled = scaler.transform(X_raw)
        
        # Build strict sequential dataset
        targets_dict = {'binary_size': Y_true}
        val_dataset = WingoSequenceDataset(X_scaled, targets_dict, self.seq_len)
        
        # Custom DataLoader to saturate the CPU and Dual GPUs
        num_workers = self.config['system']['max_workers']
        val_loader = torch.utils.data.DataLoader(
            val_dataset,
            batch_size=2048, # Massive inference batch
            shuffle=False,
            num_workers=num_workers,
            pin_memory=True
        )
        
        meta_X_blocks = []
        meta_Y_blocks = []
        
        with torch.no_grad():
            for batch_idx, (batch_X, batch_Y) in enumerate(val_loader):
                batch_X = batch_X.to(self.device, non_blocking=True)
                
                # --- 1. PyTorch Deep Models Inference (AMP Enabled) ---
                with autocast():
                    p_lstm = torch.sigmoid(self.lstm(batch_X)['binary_size']).squeeze()
                    p_trans = torch.sigmoid(self.transformer(batch_X)['binary_size']).squeeze()
                    
                    reconstructed = self.vae(batch_X)['reconstructed']
                    vae_error = torch.mean((reconstructed - batch_X) ** 2, dim=[1, 2])
                    
                # --- 2. XGBoost Inference ---
                X_last_step = batch_X[:, -1, :].cpu().numpy()
                p_xgb = self.xgb.predict_proba(X_last_step)[:, 1]
                p_xgb_tensor = torch.tensor(p_xgb, dtype=torch.float32, device=self.device)
                
                # Stack block
                batch_meta = torch.stack([p_lstm, p_trans, p_xgb_tensor, vae_error], dim=1)
                
                meta_X_blocks.append(batch_meta.cpu())
                meta_Y_blocks.append(batch_Y['binary_size'].cpu())
                
        meta_X = torch.cat(meta_X_blocks, dim=0)
        meta_Y = torch.cat(meta_Y_blocks, dim=0)
        
        logger.info(f"Level-2 Matrix Generated: {meta_X.shape[0]} samples.")
        return meta_X, meta_Y


class MetaLearnerTrainer:
    """
    Trains the Attention-Gated Neural Aggregator and strictly calibrates the output.
    """
    def __init__(self, config: dict, device: torch.device, num_models: int):
        self.config = config
        self.device = device
        self.meta_model = NeuralMetaAggregator(num_models=num_models).to(device)
        
        self.meta_dir = os.path.join(PROJECT_ROOT, self.config['paths']['meta_learner_artifact_dir'])
        os.makedirs(self.meta_dir, exist_ok=True)

    def fit_aggregator(self, X_meta: torch.Tensor, Y_meta: torch.Tensor):
        logger.info("="*60)
        logger.info("TRAINING DYNAMIC ATTENTION AGGREGATOR")
        
        X_meta = X_meta.to(self.device)
        Y_meta = Y_meta.to(self.device).unsqueeze(1)
        
        # LBFGS evaluates the entire validation matrix simultaneously for absolute precision
        optimizer = LBFGS(self.meta_model.parameters(), lr=0.1, max_iter=250)
        criterion = nn.BCEWithLogitsLoss()
        
        def closure():
            optimizer.zero_grad()
            logits = self.meta_model(X_meta)
            loss = criterion(logits, Y_meta)
            loss.backward()
            return loss
            
        optimizer.step(closure)
        
        self.meta_model.eval()
        with torch.no_grad():
            final_logits = self.meta_model(X_meta)
            final_probs = torch.sigmoid(final_logits).cpu().numpy().flatten()
            y_true = Y_meta.cpu().numpy().flatten()
            
            auc = roc_auc_score(y_true, final_probs)
            brier = brier_score_loss(y_true, final_probs)
            
        logger.info(f"Attention Aggregator Training Complete -> AUC: {auc:.4f} | Brier Score: {brier:.4f}")
        torch.save(self.meta_model.state_dict(), os.path.join(self.meta_dir, "meta_aggregator_weights.pt"))
        
        return final_probs, y_true

    def calibrate_probabilities(self, meta_probs: np.ndarray, y_true: np.ndarray):
        """
        Platt Scaling (Logistic Calibration).
        Maps the raw neural network output to pure statistical reality.
        """
        logger.info("Applying Platt Scaling Calibration for Financial Execution...")
        
        calibrator = LogisticRegression(solver='lbfgs')
        meta_probs_2d = meta_probs.reshape(-1, 1)
        
        calibrator.fit(meta_probs_2d, y_true)
        
        calibrated_probs = calibrator.predict_proba(meta_probs_2d)[:, 1]
        raw_brier = brier_score_loss(y_true, meta_probs)
        cal_brier = brier_score_loss(y_true, calibrated_probs)
        
        logger.info(f"Calibration Shift Results:")
        logger.info(f" -> Raw Brier Score: {raw_brier:.5f} (Lower is better)")
        logger.info(f" -> Calibrated Brier Score: {cal_brier:.5f}")
        
        joblib.dump(calibrator, os.path.join(self.meta_dir, "platt_calibrator.joblib"))
        logger.info("Platt Calibrator artifact saved.")


def execute_meta_pipeline():
    config_path = os.path.join(PROJECT_ROOT, "config", "global_config.yaml")
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)
        
    device = torch.device(config['system']['device'] if torch.cuda.is_available() else "cpu")
    
    data_path = os.path.join(PROJECT_ROOT, config['paths']['processed_data_path'])
    df = pd.read_csv(data_path).sort_values(by='issue_id').reset_index(drop=True)
    df = df.dropna()
    
    split_idx = int(len(df) * config['data_pipeline']['preprocessing']['train_test_split_ratio'])
    val_df = df.iloc[split_idx:].reset_index(drop=True)
    
    scaler_path = os.path.join(PROJECT_ROOT, config['paths']['scaler_artifact_dir'], "master_scaler.joblib")
    scaler = joblib.load(scaler_path)
    
    builder = Level2DataBuilder(config, device)
    input_dim = len(feature_config.MODEL_INPUT_FEATURES)
    
    builder.load_frozen_artifacts(input_dim)
    X_meta, Y_meta = builder.generate_meta_matrix(val_df, scaler)
    
    actual_num_models = X_meta.shape[1]
    logger.info(f"Dynamic Dimension Check: Detected {actual_num_models} Base Models in Level-2 Matrix.")
    
    trainer = MetaLearnerTrainer(config, device, num_models=actual_num_models)
    raw_meta_probs, y_true = trainer.fit_aggregator(X_meta, Y_meta)
    trainer.calibrate_probabilities(raw_meta_probs, y_true)
    
    logger.info("="*60)
    logger.info("PHASE 4: CLOUD TRAINING ENGINES OFFICIALLY COMPLETE.")
    logger.info("All Artifacts Locked. Ready for Phase 5: Live Inference.")
    logger.info("="*60)


if __name__ == "__main__":
    execute_meta_pipeline()